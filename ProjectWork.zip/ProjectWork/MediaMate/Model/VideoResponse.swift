//
//  VideoResponse.swift
//  MediaMate
//
//  Created by Sharma, Sambhav (Contractor) on 08/06/23.
//

import Foundation

struct VideoResponse: Decodable {
    
    var items: [VideoContent]?
    
    enum CodingKeys : String, CodingKey {
        
        case items
    }
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        self.items = try container.decode([VideoContent].self , forKey: .items)
    }
}
