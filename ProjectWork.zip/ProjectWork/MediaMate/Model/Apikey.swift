//
//  Apikey.swift
//  MediaMate
//
//  Created by Sharma, Sambhav (Contractor) on 07/06/23.
//

import Foundation

struct VideoApi {
   static var api_key = "AIzaSyA-3YtXCDKmBvCLvDd3a1liPLrjCrGn01k"
   static var api_url = "https://youtube.googleapis.com/youtube/v3/search?part=snippet&order=date&q=skateboarding%20dog&type=video&videoDefinition=high&key=\(api_key)"
}
