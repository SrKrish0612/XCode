//
//  ViewController.swift
//  MediaMate
//
//  Created by Sharma, Sambhav (Contractor) on 06/06/23.
//

import UIKit

class ViewController: UIViewController,ModelDelegate{
    
    var videoModel = VideoModel()
    var showVideo = [VideoContent]()

    @IBOutlet weak var VideoTableView: UITableView!
    
    
    @IBOutlet weak var filterBtn: UIBarButtonItem!
    
    
    @IBOutlet weak var searchVideoT: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        filterBy()
        

        
        //set itself as the datasource and delegate
        VideoTableView.delegate = self
        VideoTableView.dataSource = self
        
        //Set itself as the delegate of the videoModel
        videoModel.delegate = self
        videoModel.getVideos(sVideo: "")
    }
    
    
    @IBAction func searchClick(_ sender: Any) {
        let video = searchVideoT.text ?? ""
        
        videoModel.getVideos(sVideo: video)
    }
    
    
    
//Model Delegate Methods
        func fetchVideo(_ videos: [VideoContent]) {
        
        //Set the returned video to our showVideo property
            self.showVideo = videos
            
        // Refresh the tableView
            VideoTableView.reloadData()
    }
    
    
    func filterBy(){
        let publishedDate = UIAction(title: "Published date"){ _ in
            print("Published date is selected")
        }
        let rating = UIAction(title: "Rating"){ _ in print("Rating is selected")
    
        }
        let noOfViews = UIAction(title: "No.of.views"){ _ in
            print("No.of.views is selected")
            
        }
        let sort = UIMenu(title: "Sort by:", children: [publishedDate, rating, noOfViews])
        
        filterBtn.menu = sort
    }


}
//-> Datasource Methods
extension ViewController : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return showVideo.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = VideoTableView.dequeueReusableCell(withIdentifier: "VideoCell", for: indexPath) as! VideoTableViewCell
        
        //configure the cell with the data
        let video = self.showVideo[indexPath.row]
        cell.setCell(video)
        
        //return the cell
        return cell 
    }
    
    
}
//-> Delegate Methods
extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}
