//
//  ViewController.swift
//  MediaMate
//
//  Created by Sharma, Sambhav (Contractor) on 06/06/23.
//

import UIKit

class ViewController: UIViewController,ModelDelegate{
    
    var videoModel = VideoModel()
    var showVideo = [VideoContent]()

    @IBOutlet weak var VideoTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //set itself as the datasource and delegate
        VideoTableView.delegate = self
        VideoTableView.dataSource = self
        
        //Set itself as the delegate of the videoModel
        videoModel.delegate = self
        videoModel.getVideos()
    }
    
//Model Delegate Methods
        func fetchVideo(_ videos: [VideoContent]) {
        
        //Set the returned video to our showVideo property
            self.showVideo = videos
            
        // Refresh the tableView
            VideoTableView.reloadData()
    }


}
//-> Datasource Methods
extension ViewController : UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return showVideo.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = VideoTableView.dequeueReusableCell(withIdentifier: "VideoCell", for: indexPath) as! VideoTableViewCell
        
        //configure the cell with the data
        let video = self.showVideo[indexPath.row]
        cell.setCell(video)
        
        //return the cell
        return cell 
    }
    
    
}
//-> Delegate Methods
extension ViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }
}
