//
//  VideoModel.swift
//  MediaMate
//
//  Created by Sharma, Sambhav (Contractor) on 07/06/23.
//

import Foundation

protocol ModelDelegate : AnyObject {
    
    func fetchVideo(_ videos : [VideoContent])
}

struct VideoModel {
    
    var delegate : ModelDelegate?
    
    func getVideos() {
   
        // Create a URL object
        let url = URL(string: VideoApi.api_url)
        
        guard url != nil else {
            return
        }
        // Get a URLSession Object
        let session = URLSession.shared
        
        //Get a data task from the URLSession Object
        let dataTask = session.dataTask(with: url!) { (data, response, error) in
            //Check for any error
            if error != nil || data == nil {
                return
            }
            do {
                // Parse the data into video object
                let decoder = JSONDecoder()
                //Standard format for date -> Published key
                decoder.dateDecodingStrategy = .iso8601
                
                let response = try decoder.decode(VideoResponse.self, from: data!)
                
                if response.items != nil {
                    
                    DispatchQueue.main.async {
                        
                        //Call the fetchvideo method of the delegate
                        self.delegate?.fetchVideo(response.items!)
                        
                    }
                    
                }
                dump(response)
                
            }catch {
                
            }
            
        }
        
        // Resume Task
        dataTask.resume()
    }
}
