//
//  VideoTableViewCell.swift
//  MediaMate
//
//  Created by Sharma, Sambhav (Contractor) on 08/06/23.
//

import UIKit

class VideoTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var thumbNailImage: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    
    @IBOutlet weak var dateLabel: UILabel!
    
    var video: VideoContent?
    
    func setCell(_ viDeo: VideoContent) {
        
        self.video = viDeo
        
        //Checking for Video
        guard self.video != nil else{
            return
        }
        //Set the title
        self.titleLabel.text = video?.title
        
        //Set the date
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "EEEE, MMM D, yyyy"
        self.dateLabel.text = dateformatter.string(from: video!.published )
        
        // Check and Set the thumbnail
        
        guard self.video?.thumbnail != nil else{
            return
        }
        //Download the thumbnail data
        let url = URL(string: self.video!.thumbnail)
        
        //Get the URL Session Shared Object
        let session = URLSession.shared
        
        //Create a DataTask
        let dataTask = session.dataTask(with: url!) { data, response , error in
            
            if error == nil && data != nil {
                
                //Check that the download url matches video thumbnail url
                
                if url!.absoluteString != self.video?.thumbnail {
                    //Video Cell has been recycled for another video anad doesn't match the downloaded thumbnail
                    return
                }
                
                //Create the image object
                let image = UIImage(data: data!)
                
                //Set the image view
                DispatchQueue.main.async {
                    self.thumbNailImage.image = image
                }
                
            }
     
        }
        //Resume the data
        dataTask.resume()
 
    }
}
